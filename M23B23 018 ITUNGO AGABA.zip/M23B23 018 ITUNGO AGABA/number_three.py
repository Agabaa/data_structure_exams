#Question 3:

# First algorithm: Bubble Sort
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

# Second algorithm: Quick Sort
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

unsorted_list = [14, 27, 8, 42, 11, 35, 9, 56, 23]

# For bubble sort Bubble Sort
bubble_sort_result = unsorted_list.copy()
bubble_sort(bubble_sort_result)
print("Bubble Sort Result:", bubble_sort_result)

# Sorting using Quick Sort
quick_sort_result = quick_sort(unsorted_list.copy())
print("Quick Sort Result:", quick_sort_result)
# complexity classes
# (Bubble Sort): O(n^2)
# (Quick Sort): O(n log n)